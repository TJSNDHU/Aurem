<?php
/**
 * Plugin Name:       AUREM Pixel & Intelligence
 * Plugin URI:        https://aurem.live
 * Description:       Install the AUREM AI tracking pixel, Friend Scanner, and Power Trial hooks on your WordPress site with one click. Paste your AUREM tenant ID below — done.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            AUREM
 * Author URI:        https://aurem.live
 * License:           MIT
 * Text Domain:       aurem-pixel
 */

if (!defined('ABSPATH')) {
    exit; // Security: no direct access.
}

define('AUREM_PIXEL_VERSION', '1.0.0');
define('AUREM_DEFAULT_ENDPOINT', 'https://ai-platform-preview-3.preview.emergentagent.com');

require_once plugin_dir_path(__FILE__) . 'includes/class-aurem-settings.php';

class AUREM_Pixel {

    public function __construct() {
        add_action('plugins_loaded', [$this, 'init_settings']);
        add_action('wp_head', [$this, 'inject_pixel'], 1);
        add_action('wp_footer', [$this, 'inject_friend_scanner'], 99);
    }

    public function init_settings() {
        new AUREM_Settings();
    }

    /**
     * Tracking pixel — fires on every page view.
     * Sends anonymous telemetry to AUREM for the "Site Audit" feature.
     */
    public function inject_pixel() {
        $opts = get_option('aurem_pixel_options', []);
        $tenant = isset($opts['tenant_id']) ? sanitize_text_field($opts['tenant_id']) : '';
        $endpoint = isset($opts['api_endpoint']) && $opts['api_endpoint']
            ? esc_url_raw($opts['api_endpoint'])
            : AUREM_DEFAULT_ENDPOINT;

        if (!$tenant) {
            return;
        }

        $endpoint = rtrim($endpoint, '/');
        ?>
        <!-- AUREM Pixel — <?php echo esc_html(AUREM_PIXEL_VERSION); ?> -->
        <script>
        (function () {
          window.__aurem = window.__aurem || {
            tenant: "<?php echo esc_js($tenant); ?>",
            endpoint: "<?php echo esc_js($endpoint); ?>",
            q: []
          };
          window.aurem = function () { window.__aurem.q.push(arguments); };
          var a = document.createElement('script');
          a.async = true;
          a.src = window.__aurem.endpoint + '/static/aurem-tracker.js';
          document.head.appendChild(a);
          // Fire page_view immediately
          fetch(window.__aurem.endpoint + '/api/pixel/event', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
              tenant_id: window.__aurem.tenant,
              event: 'page_view',
              url: window.location.href,
              referrer: document.referrer || null,
              ua: navigator.userAgent,
              ts: Date.now()
            }),
            keepalive: true
          }).catch(function(){});
        })();
        </script>
        <!-- /AUREM Pixel -->
        <?php
    }

    /**
     * Friend Scanner widget — floating button that lets visitors scan
     * other websites to unlock trial features (viral loop).
     */
    public function inject_friend_scanner() {
        $opts = get_option('aurem_pixel_options', []);
        $tenant = isset($opts['tenant_id']) ? sanitize_text_field($opts['tenant_id']) : '';
        $enabled = !empty($opts['friend_scanner_enabled']);
        if (!$tenant || !$enabled) {
            return;
        }
        $endpoint = isset($opts['api_endpoint']) && $opts['api_endpoint']
            ? esc_url_raw($opts['api_endpoint'])
            : AUREM_DEFAULT_ENDPOINT;
        $endpoint = rtrim($endpoint, '/');
        ?>
        <div id="aurem-friend-scanner-root"
             data-aurem-tenant="<?php echo esc_attr($tenant); ?>"
             data-aurem-endpoint="<?php echo esc_attr($endpoint); ?>"></div>
        <script defer src="<?php echo esc_url($endpoint); ?>/static/friend-scanner.js"></script>
        <?php
    }
}

new AUREM_Pixel();

// Activation / Deactivation hooks
register_activation_hook(__FILE__, function () {
    if (!get_option('aurem_pixel_options')) {
        add_option('aurem_pixel_options', [
            'tenant_id' => '',
            'api_endpoint' => AUREM_DEFAULT_ENDPOINT,
            'friend_scanner_enabled' => false,
        ]);
    }
});

register_deactivation_hook(__FILE__, function () {
    // Intentionally keep options on deactivate so users don't lose their tenant ID.
});
