<?php
/**
 * AUREM Pixel — Settings page under Settings → AUREM.
 */
if (!defined('ABSPATH')) {
    exit;
}

class AUREM_Settings {

    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function add_menu() {
        add_options_page(
            'AUREM Pixel Settings',
            'AUREM',
            'manage_options',
            'aurem-pixel',
            [$this, 'render_page']
        );
    }

    public function register_settings() {
        register_setting('aurem_pixel_group', 'aurem_pixel_options', [$this, 'sanitize']);

        add_settings_section('aurem_main', 'Connection', function () {
            echo '<p>Paste your AUREM tenant ID from your dashboard → Settings → Integrations.</p>';
        }, 'aurem-pixel');

        add_settings_field('tenant_id', 'Tenant ID (BIN)', [$this, 'field_tenant'], 'aurem-pixel', 'aurem_main');
        add_settings_field('api_endpoint', 'API Endpoint', [$this, 'field_endpoint'], 'aurem-pixel', 'aurem_main');
        add_settings_field('friend_scanner_enabled', 'Enable Friend Scanner widget', [$this, 'field_scanner'], 'aurem-pixel', 'aurem_main');
    }

    public function sanitize($input) {
        return [
            'tenant_id' => sanitize_text_field($input['tenant_id'] ?? ''),
            'api_endpoint' => esc_url_raw($input['api_endpoint'] ?? AUREM_DEFAULT_ENDPOINT),
            'friend_scanner_enabled' => !empty($input['friend_scanner_enabled']),
        ];
    }

    private function get_opts() {
        return get_option('aurem_pixel_options', [
            'tenant_id' => '',
            'api_endpoint' => AUREM_DEFAULT_ENDPOINT,
            'friend_scanner_enabled' => false,
        ]);
    }

    public function field_tenant() {
        $o = $this->get_opts();
        printf(
            '<input type="text" name="aurem_pixel_options[tenant_id]" value="%s" class="regular-text" placeholder="AUREM-XXXX" />',
            esc_attr($o['tenant_id'])
        );
    }

    public function field_endpoint() {
        $o = $this->get_opts();
        printf(
            '<input type="url" name="aurem_pixel_options[api_endpoint]" value="%s" class="regular-text" />',
            esc_attr($o['api_endpoint'])
        );
        echo '<p class="description">Leave default unless AUREM support tells you otherwise.</p>';
    }

    public function field_scanner() {
        $o = $this->get_opts();
        $checked = !empty($o['friend_scanner_enabled']) ? 'checked' : '';
        echo '<label><input type="checkbox" name="aurem_pixel_options[friend_scanner_enabled]" value="1" ' . $checked . ' /> Show viral Friend Scanner button on public pages</label>';
    }

    public function render_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1>AUREM Pixel & Intelligence</h1>
            <p>Pixel version <?php echo esc_html(AUREM_PIXEL_VERSION); ?> — once connected your site's traffic, conversions and SEO signals flow into your AUREM dashboard.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields('aurem_pixel_group');
                do_settings_sections('aurem-pixel');
                submit_button('Save Connection');
                ?>
            </form>
            <hr />
            <h2>Need help?</h2>
            <ol>
                <li>Log in to your AUREM dashboard.</li>
                <li>Go to <strong>Settings → Integrations → WordPress</strong>.</li>
                <li>Copy your Tenant ID (starts with <code>AUREM-</code>).</li>
                <li>Paste it above and click <em>Save Connection</em>.</li>
            </ol>
        </div>
        <?php
    }
}
