=== AUREM Pixel & Intelligence ===
Contributors: aurem
Tags: analytics, ai, lead-generation, pixel, seo
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: MIT
License URI: https://opensource.org/licenses/MIT

One-click AUREM AI pixel installation for WordPress. Connect your site's traffic to the AUREM intelligence engine in under 30 seconds.

== Description ==

AUREM Pixel injects the AUREM tracking pixel and optional Friend Scanner viral widget into your WordPress site's header and footer. No code required.

Features:
* One-click pixel installation
* Automatic page view tracking
* Optional Friend Scanner viral widget (lets visitors scan competitor sites)
* CASL / GDPR safe (respects Do Not Track headers)
* Zero performance impact (async script)

== Installation ==

1. Upload the plugin ZIP via Plugins → Add New → Upload Plugin.
2. Activate.
3. Go to Settings → AUREM.
4. Paste your Tenant ID from your AUREM dashboard.

== Changelog ==

= 1.0.0 =
* Initial release
* wp_head pixel injection
* Friend Scanner widget (optional)
* Settings page under Settings → AUREM
